<?php

//require_once '../../funtions.php';



$vector = array();
/// cargamos las constantes de configuración
//require_once 'base/fs_mysql.php';
$vector["exito"] = true;

echo json_encode($vector);	
?>