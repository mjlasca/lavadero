<?php
/*
 * This file is part of facturacion_base
 * Copyright (C) 2013-2017  Carlos Garcia Gomez  neorazorx@gmail.com
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

require_once 'plugins/facturacion_base/extras/fbase_controller.php';

class tpv_caja extends fbase_controller
{

    public $almacen;
    public $caja;
    public $offset;
    public $resultados;
    public $serie;
    public $terminal;
    public $terminales;
    public $datos_cierre_caja;
    public $agente;

    public function __construct()
    {
        parent::__construct(__CLASS__, 'Arqueos y terminales', 'TPV');
    }

    protected function private_core()
    {
        parent::private_core();
        
        $this->share_extensions();
        
        
        
        
        $this->almacen = new almacen();
        $this->caja = new caja();
        $this->serie = new serie();
        
        $terminal = new terminal_caja();

        if (isset($_POST['nuevot'])) { /// nuevo terminal
            $this->nuevo_terminal($terminal);
        } else if (isset($_POST['idt'])) { /// editar terminal
            $this->editar_terminal($terminal);
        } else if (isset($_GET['deletet'])) { /// eliminar terminal
            $this->eliminar_terminal($terminal);
        } else if (isset($_GET['delete'])) { /// eliminar caja
            $this->eliminar_caja();
        } else if (isset($_GET['cerrar'])) {
            $sql = "SELECT * FROM facturascli WHERE id_arqueo='".$_GET['cerrar']."' AND pagada<1  AND codpago='CONT'";
            
            if($this->db->select($sql))
                $this->new_error_msg ("No se puede cerrar el arqueo si no ha pagado todas las facturas contado");
            else
                $this->cerrar_caja();
        }

        $this->offset = 0;
        if (isset($_GET['offset'])) {
            $this->offset = intval($_GET['offset']);
        }

        $this->resultados = $this->caja->all($this->offset);
        //$this->datos_cierre_caja($identificador);
        $this->terminales = $terminal->all();
        
        
        
        if (isset($_GET['imprimir_caja'])) {
                        $this->terminal = new terminal_caja();
                        $t = new terminal_caja();
                        $t = $this->terminal->get_cod("TT");
                        
                        $caja2 = new caja();
                        $this->agente = new agente();
                        
                        $this->cerrar_caja1($caja2->get_id($_GET['imprimir_caja']), $t);
                        
        }
        
        
    }
    
    
    public  function datos_cierre_caja($identificador, $fecha1="", $fecha2="", $arqueo){
       /* $sql="SELECT  t1.codagente, t2.id, "
                . " SUM(t1.total) as total "
                . "  FROM facturascli t1 INNER JOIN cajas t2 ON "
                . " IF(t2.f_fin=null, t1.horaas > t2.f_inicio, (t1.horaas BETWEEN t2.f_inicio AND t2.f_fin)) AND  t1.anulada=0  group by t2.id ";*/
        
        //$sql="SELECT  t1.codagente, t2.id, SUM(t1.total) as total "
          //      . " FROM facturascli t1 INNER JOIN cajas t2 ON (t1.horaas BETWEEN t2.f_inicio AND t2.f_fin) AND t1.codagente= '".$identificador."' AND   t1.pagada='1'    group by t2.id ";
        

        //if($arqueo > 73){
            $sql="SELECT  SUM(total) as total FROM facturascli WHERE id_arqueo = '".$arqueo."' AND  pagada=1 AND anulada = 0 AND codagente= '".$identificador."'  ";
        /*}else{
        $sql="SELECT  t1.codagente, t2.id, SUM(t1.total) as total, DATE(t1.horaas) as horaas "
              . " FROM facturascli t1 INNER JOIN cajas t2 "
                . " ON  ( TIME(t1.horaas)  BETWEEN '".substr($fecha1, -8)."' AND  '".substr($fecha2, -8)."' ) "
                . " AND DATE(t1.horaas) = DATE(t2.f_inicio) AND t1.codagente= '".$identificador."' AND "
                . "  t1.pagada=1 AND t1.anulada = 0   group by t2.id ";
        
        }*/
      
        
        
        $this->datos_cierre_caja = $this->db->select($sql);
        
        
       
        
        if($this->datos_cierre_caja) {
             /*$sql = "UPDATE facturascli SET id_arqueo='".$arqueo."' WHERE ( TIME(horaas)  BETWEEN '".substr($fecha1, -8)."' AND  '".substr($fecha2, -8)."'  )"
                . "AND DATE(horaas) = '".$this->datos_cierre_caja[0]["horaas"]."' "
                . " AND codagente = '".$identificador."' ";
        
             $this->db->exec($sql);
            echo "</br></br>".$sql;*/
            $this->datos_cierre_caja = $this->datos_cierre_caja[0];
        }
        else{
            $this->datos_cierre_caja["total"] = 0;
        }
        
        
    }

    private function nuevo_terminal(&$terminal)
    {
        $terminal->codalmacen = $_POST['codalmacen'];
        $terminal->codserie = $_POST['codserie'];

        $terminal->codcliente = NULL;
        if ($_POST['codcliente'] != '') {
            $terminal->codcliente = $_POST['codcliente'];
        }

        $terminal->anchopapel = intval($_POST['anchopapel']);
        $terminal->comandoapertura = $_POST['comandoapertura'];
        $terminal->comandocorte = $_POST['comandocorte'];
        $terminal->num_tickets = intval($_POST['num_tickets']);
        $terminal->sin_comandos = isset($_POST['sin_comandos']);

        if ($terminal->save()) {
            $this->new_message('Terminal añadido correctamente.');
            header('Location: index.php?page=tpv_recambios');
        } else
            $this->new_error_msg('Error al guardar los datos.');
    }

    private function editar_terminal(&$terminal)
    {
        $t2 = $terminal->get($_POST['idt']);
        if ($t2) {
            $t2->codalmacen = $_POST['codalmacen'];
            $t2->codserie = $_POST['codserie'];

            $t2->codcliente = NULL;
            if ($_POST['codcliente'] != '') {
                $t2->codcliente = $_POST['codcliente'];
            }

            $t2->anchopapel = intval($_POST['anchopapel']);
            $t2->comandoapertura = $_POST['comandoapertura'];
            $t2->comandocorte = $_POST['comandocorte'];
            $t2->num_tickets = intval($_POST['num_tickets']);
            $t2->sin_comandos = isset($_POST['sin_comandos']);

            if ($t2->save()) {
                $this->new_message('Datos guardados correctamente.');
            } else
                $this->new_error_msg('Error al guardar los datos.');
        } else
            $this->new_error_msg('Terminal no encontrado.');
    }

    private function eliminar_terminal(&$terminal)
    {
        if ($this->user->admin) {
            $t2 = $terminal->get($_GET['deletet']);
            if ($t2) {
                if ($t2->delete()) {
                    $this->new_message('Terminal eliminado correctamente.');
                } else
                    $this->new_error_msg('Error al eliminar el terminal.');
            } else
                $this->new_error_msg('Terminal no encontrado.');
        } else
            $this->new_error_msg("Solamente un administrador puede eliminar terminales.");
    }

    private function eliminar_caja()
    {
        if ($this->user->admin) {
            $caja2 = $this->caja->get($_GET['delete']);
            if ($caja2) {
                if ($caja2->delete()) {
                    $this->new_message("Arqueo eliminado correctamente.");
                } else
                    $this->new_error_msg("¡Imposible eliminar el arqueo!");
            } else
                $this->new_error_msg("Arqueo no encontrado.");
        } else
            $this->new_error_msg("Solamente un administrador puede eliminar arqueos.");
    }

    private function cerrar_caja()
    {
        if ($this->user->admin) {
            $caja2 = $this->caja->get($_GET['cerrar']);
            
            if ($caja2) {
                $caja2->fecha_fin = Date('d-m-Y H:i:s');
                $caja2->cierremanual = $_REQUEST["dinero_caja"];
                if ($caja2->save()) {
                    $this->new_message("Arqueo cerrado correctamente.");
                } else
                    $this->new_error_msg("¡Imposible cerrar el arqueo!");
            } else
                $this->new_error_msg("Arqueo no encontrado.");
        }
        else {
            $this->new_error_msg("El procedimiento normal es cerrar el arqueo desde el propio TPV, pulsando el botón"
                . " <b>cerrar caja</b>. Para forzar el cierre desde esta pantalla debes ser administrador.");
        }
    }

    public function anterior_url()
    {
        $url = '';

        if ($this->offset > 0) {
            $url = $this->url() . "&offset=" . ($this->offset - FS_ITEM_LIMIT);
        }

        return $url;
    }

    public function siguiente_url()
    {
        $url = '';

        if (count($this->resultados) == FS_ITEM_LIMIT) {
            $url = $this->url() . "&offset=" . ($this->offset + FS_ITEM_LIMIT);
        }

        return $url;
    }
    
     /*
     * Se consulta las facturas para saber cuánto ha generado por lavador o por 
      * artículos, es decir, cuando la factura no tiene ningún lavador asignado
     */
    private function desgloce_lavador($empleado, $id_arqueo){
        
        $sql = "SELECT SUM(total) as total, proveedor_servicio FROM facturascli WHERE  codagente = '".$empleado."' AND id_arqueo='".$id_arqueo."' GROUP BY proveedor_servicio";
        $consulta = $this->db->select($sql);
        return $consulta;
    }
    
    
    /*
     * Se consulta las facturas crédito que se hicieron en el arqueo con id $id
     * y el empleado
     */
    private function facturas_credito($empleado, $id_arqueo){
        
        $sql = "SELECT SUM(total) as total FROM facturascli WHERE pagada=0 AND  codagente = '".$empleado."' AND id_arqueo='".$id_arqueo."'";
        
        $consulta = $this->db->select($sql);
        
        if($consulta)
            return $consulta[0]["total"];
        else
            return 0;
        
    }
    
    
    /*
     * Se consulta las facturas contado que se hicieron en el arqueo con id $id
     * y el empleado
     */
    private function facturas_contado($empleado, $id_arqueo){
        
        $sql = "SELECT SUM(total) as total FROM facturascli WHERE pagada=1 AND  codagente = '".$empleado."' AND id_arqueo='".$id_arqueo."'";
        
        $consulta = $this->db->select($sql);
        
        if($consulta)
            return $consulta[0]["total"];
        else
            return 0;
        
    }
    
    private function cerrar_caja1($caja_im, $terminal)
    {
        
            if ($this->terminal) {
                $this->terminal->cod_letra_tickect();
                $this->terminal->anchopapel = 28;
                $this->terminal->add_linea_big("\nCIERRE DE CAJA:\n\n");
                //$this->terminal->add_linea("Empleado: " . $this->user->codagente . " " . $this->agente->get_fullname() . "\n");
                
                $this->terminal->add_linea("Caja: " . $caja_im[0]["fs_id"] ."  ID Arqueo: ".$caja_im[0]["id"]." \n");
                $this->terminal->add_linea("Fecha Arqueo: \n" . date("Y-m-d H:i:s"). "\n");
                $this->terminal->add_linea("Fecha ini: \n" . $caja_im[0]["f_inicio"] . "\n");
                
                $this->terminal->add_linea("Fecha fin: \n" . $caja_im[0]["f_fin"] . "\n");
                $this->terminal->add_linea("Diferencia: $ " . $this->formato_moneda($caja_im[0]["d_fin"] - $caja_im[0]["d_inicio"]) . "\n");
                $this->terminal->add_linea("Tickets: " . $caja_im[0]["tickets"] . "\n\n");
                $this->terminal->add_linea_big("Arqueo caja: \n\n");
                
                
                /*
                 * sprintf sirve para alinear la impresión a la derecha, el número en $this->terminal->anchopapel - 16 determina los espacios después del título
                 * y así acomoda cada resultado alineado a la derecha
                 */
                $this->terminal->add_linea("Dinero inic $" . sprintf("%" . ($this->terminal->anchopapel - 13) . "s",$this->formato_moneda($caja_im[0]["d_inicio"]) ) . "\n");
                $this->terminal->add_linea("Fact. Ctado $". sprintf("%" . ($this->terminal->anchopapel - 12) . "s", $this->formato_moneda($this->facturas_contado($caja_im[0]["codagente"], $caja_im[0]["id"])). "\n") );
                $this->terminal->add_linea("Fact. Cdito $". sprintf("%" . ($this->terminal->anchopapel - 12) . "s", $this->formato_moneda($this->facturas_credito($caja_im[0]["codagente"], $caja_im[0]["id"])). "\n") );
                $this->terminal->add_linea("Dnero Manua $" .  sprintf("%" . ($this->terminal->anchopapel - 12) . "s", $this->formato_moneda($caja_im[0]["cierremanual"]) . "\n" ));
                $this->terminal->add_linea("Dnero final $" .  sprintf("%" . ($this->terminal->anchopapel - 11) . "s", $this->formato_moneda($caja_im[0]["d_fin"] - $this->facturas_credito($caja_im[0]["codagente"], $caja_im[0]["id"])) . "\n\n" ));
                $this->terminal->add_linea_big("Por Lavador \n\n");
                
                
                if($this->desgloce_lavador($caja_im[0]["codagente"], $caja_im[0]["id"])){
                    $consulta = $this->desgloce_lavador($caja_im[0]["codagente"], $caja_im[0]["id"]);
                    for($i=0 ; $i < count($consulta) ; $i++){
                        if($consulta[$i]["proveedor_servicio"] == "0")
                            $this->terminal->add_linea("ARTICULOS:  $" .sprintf("%" . ($this->terminal->anchopapel - 12) . "s", $this->formato_moneda($consulta[$i]["total"]) . "\n"));
                        else{
                            $proveedor_temp = substr($consulta[$i]["proveedor_servicio"], 0, 11);
                            
                            if(strlen($consulta[$i]["proveedor_servicio"]) > 11){
                                $proveedor_temp .= ".$";
                            }else{
                                while(strlen($proveedor_temp)<=11){
                                    $proveedor_temp .= " ";
                                }
                                $proveedor_temp .= "$";
                                
                            }
                            $this->terminal->add_linea($proveedor_temp. sprintf("%" . ($this->terminal->anchopapel - 12) . "s", $this->formato_moneda($consulta[$i]["total"]) . "\n"));
                        }
                        
                    }
                    $this->terminal->add_linea("\nTOTAL:      $" . sprintf("%" . ($this->terminal->anchopapel - 11) . "s", $this->formato_moneda($caja_im[0]["d_fin"]) . "\n\n"));
                }
                $this->terminal->add_linea("Observaciones:\n\n\n\n");
                $this->terminal->add_linea("Firma:\n\n\n\n\n\n\n\n\n\n");
                $this->terminal->cortar_papel();
                $this->terminal->codserie = "TT";
                $this->terminal->id = $terminal->id;
                
                //print_r($this->terminal);

                $this->terminal->save();
                /*
                /// recargamos la página
                header('location: ' . $this->url() . '&terminal=' . $this->terminal->id);
            } else {
                /// recargamos la página
                header('location: ' . $this->url());*/
            }
            
        
    }
    
    public function formato_moneda($number){
            $text =number_format($number, 2); 
            return  $text;
        
        }
    private function share_extensions()
    {
        $fsext = new fs_extension();
        $fsext->name = 'api_remote_printer';
        $fsext->from = __CLASS__;
        $fsext->type = 'api';
        $fsext->text = 'remote_printer';
        $fsext->save();
    }
}
